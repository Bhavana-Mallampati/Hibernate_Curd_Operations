package com.model;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import jakarta.persistence.TypedQuery;

public class StudentManager {
	public String insertData(Student S)throws Exception
	{
		//SessionFactory---object---interface---org.hibernate
		//Session-----interface
		//Configuration--class--object
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = factory.openSession();
		session.getTransaction().begin();
		session.persist(S);
		session.getTransaction().commit();
		session.close();
		factory.close();
		return "Data Inserted Successfully...";
	}
	public List<Student> getData() throws Exception {
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = factory.openSession();
		session.getTransaction().begin();
		List<Student> list=new ArrayList<Student>();
		TypedQuery<Student> qry=session.createQuery("select s from Student s",Student.class);
		list=qry.getResultList();
		session.getTransaction().commit();
		session.close();
		factory.close();
		return list;
	}
	public String updateData(Student s1) throws Exception {
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = factory.openSession();
		session.getTransaction().begin();
		Student s2=session.find(Student.class, s1.sid);
		s2.setSname(s1.getSname());
		s2.setSdept(s1.getSdept());
		session.merge(s2);
		session.getTransaction().commit();
		session.close();
		factory.close();
		return "Updation Done Successfully";
	}
	public String deleteData(int sid) throws Exception {
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = factory.openSession();
		session.getTransaction().begin();
		Student s2=session.find(Student.class, sid);
		session.remove(s2);
		session.getTransaction().commit();
		session.close();
		factory.close();
		return "Deletion Done Successfully";
	}
}
